// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/ArenaToken.sol";
import "../src/ArenaVault.sol";
import "../src/SeasonSettler.sol";
import "../src/AgentNFA.sol";
import "../src/AgentAccountRegistry.sol";
import "../src/LearningRootOracle.sol";

contract Deploy is Script {
    function run() external {
        address owner = vm.envAddress("OWNER");
        uint256 pk = vm.envUint("PRIVATE_KEY");

        vm.startBroadcast(pk);

        ArenaToken token = new ArenaToken(owner, 100_000_000 ether);
        ArenaVault vault = new ArenaVault(address(token), owner);
        SeasonSettler settler = new SeasonSettler(address(vault), owner);
        AgentNFA agentNfa = new AgentNFA(owner);
        AgentAccountRegistry registry = new AgentAccountRegistry();
        LearningRootOracle learningOracle = new LearningRootOracle(owner);

        // Wire vault -> settler so submitSeasonResult can call setSeasonWeights
        vault.setSettler(address(settler));

        // Optional one-way config lock for production single-signer operation
        bool lockConfig = vm.envOr("LOCK_CONFIG", false);
        if (lockConfig) {
            vault.lockSettler();
            settler.lockVault();
        }

        vm.stopBroadcast();

        console.log("TOKEN=", address(token));
        console.log("VAULT=", address(vault));
        console.log("SETTLER=", address(settler));
        console.log("AGENT_NFA=", address(agentNfa));
        console.log("AGENT_ACCOUNT_REGISTRY=", address(registry));
        console.log("LEARNING_ROOT_ORACLE=", address(learningOracle));
        console.log("LOCK_CONFIG=", lockConfig);
    }
}
