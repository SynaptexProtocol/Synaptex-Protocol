// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./Ownable.sol";

contract LearningRootOracle is Ownable {
    bool public paused;

    struct CycleRoot {
        bytes32 root;
        uint64 submittedAt;
        bool exists;
    }

    // seasonKey => cycleKey => root
    mapping(bytes32 => mapping(bytes32 => CycleRoot)) public cycleRoots;
    // seasonKey => latest cycle count submitted
    mapping(bytes32 => uint256) public seasonCycleCount;

    event CycleRootSubmitted(string indexed seasonId, string indexed cycleId, bytes32 indexed cycleRoot);
    event Paused(address indexed by);
    event Unpaused(address indexed by);

    modifier whenNotPaused() {
        require(!paused, "LearningRootOracle: paused");
        _;
    }

    constructor(address initialOwner) Ownable(initialOwner) {}

    function submitCycleRoot(
        string calldata seasonId,
        string calldata cycleId,
        bytes32 cycleRoot
    ) external onlyOwner whenNotPaused {
        bytes32 seasonKey = keccak256(abi.encodePacked(seasonId));
        bytes32 cycleKey = keccak256(abi.encodePacked(cycleId));
        require(!cycleRoots[seasonKey][cycleKey].exists, "LearningRootOracle: cycle exists");

        cycleRoots[seasonKey][cycleKey] = CycleRoot({
            root: cycleRoot,
            submittedAt: uint64(block.timestamp),
            exists: true
        });
        seasonCycleCount[seasonKey] += 1;
        emit CycleRootSubmitted(seasonId, cycleId, cycleRoot);
    }

    function hasCycleRoot(
        string calldata seasonId,
        string calldata cycleId
    ) external view returns (bool) {
        bytes32 seasonKey = keccak256(abi.encodePacked(seasonId));
        bytes32 cycleKey = keccak256(abi.encodePacked(cycleId));
        return cycleRoots[seasonKey][cycleKey].exists;
    }

    function pause() external onlyOwner {
        paused = true;
        emit Paused(msg.sender);
    }

    function unpause() external onlyOwner {
        paused = false;
        emit Unpaused(msg.sender);
    }
}
