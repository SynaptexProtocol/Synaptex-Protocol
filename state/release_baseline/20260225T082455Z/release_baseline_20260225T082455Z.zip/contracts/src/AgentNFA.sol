// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./Ownable.sol";

contract AgentNFA is Ownable {
    string public name = "Arena Agent";
    string public symbol = "AGENT";

    uint256 public nextTokenId = 1;

    mapping(uint256 => address) public ownerOf;
    mapping(address => uint256) public balanceOf;
    mapping(uint256 => address) public getApproved;
    mapping(address => mapping(address => bool)) public isApprovedForAll;

    mapping(uint256 => string) public tokenURI;
    mapping(uint256 => bytes32) public agentKeyByToken;
    mapping(bytes32 => uint256) public tokenByAgentKey;

    event Transfer(address indexed from, address indexed to, uint256 indexed tokenId);
    event Approval(address indexed owner, address indexed spender, uint256 indexed tokenId);
    event ApprovalForAll(address indexed owner, address indexed operator, bool approved);
    event AgentRegistered(uint256 indexed tokenId, bytes32 indexed agentKey, string agentId);

    constructor(address initialOwner) Ownable(initialOwner) {}

    function mintAgent(
        address to,
        string calldata agentId,
        string calldata uri
    ) external onlyOwner returns (uint256 tokenId) {
        require(to != address(0), "AgentNFA: zero to");
        bytes32 key = keccak256(abi.encodePacked(agentId));
        require(tokenByAgentKey[key] == 0, "AgentNFA: agent exists");

        tokenId = nextTokenId++;
        ownerOf[tokenId] = to;
        balanceOf[to] += 1;
        tokenURI[tokenId] = uri;
        agentKeyByToken[tokenId] = key;
        tokenByAgentKey[key] = tokenId;

        emit Transfer(address(0), to, tokenId);
        emit AgentRegistered(tokenId, key, agentId);
    }

    function approve(address spender, uint256 tokenId) external {
        address tokenOwner = ownerOf[tokenId];
        require(tokenOwner != address(0), "AgentNFA: not minted");
        require(
            msg.sender == tokenOwner || isApprovedForAll[tokenOwner][msg.sender],
            "AgentNFA: not approved owner"
        );
        getApproved[tokenId] = spender;
        emit Approval(tokenOwner, spender, tokenId);
    }

    function setApprovalForAll(address operator, bool approved) external {
        isApprovedForAll[msg.sender][operator] = approved;
        emit ApprovalForAll(msg.sender, operator, approved);
    }

    function transferFrom(address from, address to, uint256 tokenId) public {
        require(to != address(0), "AgentNFA: zero to");
        require(ownerOf[tokenId] == from, "AgentNFA: wrong from");
        require(_isApprovedOrOwner(msg.sender, tokenId), "AgentNFA: not approved");

        getApproved[tokenId] = address(0);
        ownerOf[tokenId] = to;
        balanceOf[from] -= 1;
        balanceOf[to] += 1;

        emit Transfer(from, to, tokenId);
    }

    function _isApprovedOrOwner(address spender, uint256 tokenId) internal view returns (bool) {
        address tokenOwner = ownerOf[tokenId];
        return (
            spender == tokenOwner
            || getApproved[tokenId] == spender
            || isApprovedForAll[tokenOwner][spender]
        );
    }
}
