// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./AgentAccount.sol";

contract AgentAccountRegistry {
    event AccountCreated(
        address indexed account,
        address indexed tokenContract,
        uint256 indexed tokenId,
        uint256 chainId,
        uint256 salt
    );

    function createAccount(
        address tokenContract,
        uint256 tokenId,
        uint256 chainId,
        uint256 salt
    ) external returns (address account) {
        account = accountAddress(tokenContract, tokenId, chainId, salt);
        if (account.code.length > 0) return account;

        bytes32 deploySalt = _salt(tokenContract, tokenId, chainId, salt);
        account = address(new AgentAccount{salt: deploySalt}(tokenContract, tokenId, chainId));
        emit AccountCreated(account, tokenContract, tokenId, chainId, salt);
    }

    function accountAddress(
        address tokenContract,
        uint256 tokenId,
        uint256 chainId,
        uint256 salt
    ) public view returns (address) {
        bytes32 deploySalt = _salt(tokenContract, tokenId, chainId, salt);
        bytes memory code = abi.encodePacked(
            type(AgentAccount).creationCode,
            abi.encode(tokenContract, tokenId, chainId)
        );
        bytes32 hash = keccak256(
            abi.encodePacked(bytes1(0xff), address(this), deploySalt, keccak256(code))
        );
        return address(uint160(uint256(hash)));
    }

    function _salt(
        address tokenContract,
        uint256 tokenId,
        uint256 chainId,
        uint256 salt
    ) private pure returns (bytes32) {
        return keccak256(abi.encode(tokenContract, tokenId, chainId, salt));
    }
}
