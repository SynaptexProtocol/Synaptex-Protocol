// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./Ownable.sol";

interface IArenaVault {
    function setSeasonWeights(
        string calldata seasonId,
        string[] calldata agentIds,
        uint256[] calldata weightsWad
    ) external;
}

contract SeasonSettler is Ownable {
    bool public paused;
    bool public vaultLocked;

    struct SeasonResult {
        bytes32 leaderboardHash;
        bytes32 merkleRoot;
        uint64 settledAt;
        bool exists;
    }

    IArenaVault public vault;
    mapping(bytes32 => SeasonResult) public resultsBySeason;

    event SeasonResultSubmitted(
        string indexed seasonId,
        bytes32 indexed leaderboardHash,
        bytes32 indexed merkleRoot
    );
    event VaultUpdated(address indexed vault);
    event VaultLocked(address indexed by);
    event Paused(address indexed by);
    event Unpaused(address indexed by);

    modifier whenNotPaused() {
        require(!paused, "SeasonSettler: paused");
        _;
    }

    constructor(address vaultAddress, address initialOwner) Ownable(initialOwner) {
        require(vaultAddress != address(0), "SeasonSettler: zero vault");
        vault = IArenaVault(vaultAddress);
    }

    function setVault(address vaultAddress) external onlyOwner {
        require(!vaultLocked, "SeasonSettler: vault locked");
        require(vaultAddress != address(0), "SeasonSettler: zero vault");
        vault = IArenaVault(vaultAddress);
        emit VaultUpdated(vaultAddress);
    }

    function lockVault() external onlyOwner {
        vaultLocked = true;
        emit VaultLocked(msg.sender);
    }

    function submitSeasonResult(
        string calldata seasonId,
        bytes32 leaderboardHash,
        bytes32 merkleRoot,
        string[] calldata agentIds,
        uint256[] calldata weightsWad
    ) external onlyOwner whenNotPaused {
        require(agentIds.length == weightsWad.length, "SeasonSettler: length mismatch");
        bytes32 s = _seasonKey(seasonId);
        require(!resultsBySeason[s].exists, "SeasonSettler: season already submitted");

        vault.setSeasonWeights(seasonId, agentIds, weightsWad);
        resultsBySeason[s] = SeasonResult({
            leaderboardHash: leaderboardHash,
            merkleRoot: merkleRoot,
            settledAt: uint64(block.timestamp),
            exists: true
        });

        emit SeasonResultSubmitted(seasonId, leaderboardHash, merkleRoot);
    }

    function _seasonKey(string memory seasonId) private pure returns (bytes32) {
        return keccak256(abi.encodePacked(seasonId));
    }

    function pause() external onlyOwner {
        paused = true;
        emit Paused(msg.sender);
    }

    function unpause() external onlyOwner {
        paused = false;
        emit Unpaused(msg.sender);
    }
}
